
#' Title
#'
#' @export
#' @import jsonlite
#' @import httr
#'
hello <- function(SQL, targetdialect) {
  url <- "https://api.ohdsi.org/WebAPI/sqlrender/translate"
  payload <- list(
    SQL = SQL,
    targetdialect = targetdialect
  )
  
  response <- httr::POST(url = url, body = payload, encode = "json", httr::content_type_json())
  result <- ""
  if (httr::status_code(201)) {
    print("success")
    json <- jsonlite::fromJSON(httr::content(response, as = "text"))
    print(json)
    result <- json
  } else {
    print("fail")
  }
  return(result)
}

jeff <- function() {
  print("jeff")
}

#' Title
#'
#' @export
#'
yes <- function() {
  print("yes")
  # Construct the full path to the CSV file using system.file()
  csv_path <- system.file("csv", "replacementPatterns.csv", package = "SqlRender")
  
  # Read the CSV file into a data frame
  data <- read.csv(csv_path)
  print(data)
  data
}

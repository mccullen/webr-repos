## Use Roxygen to document package
devtools::document()

## 
restart R (or detach)
devtools::install()

- keep track of document dependencies 

pak::pkg_install("httpuv")